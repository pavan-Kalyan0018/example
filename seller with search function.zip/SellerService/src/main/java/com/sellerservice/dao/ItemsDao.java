package com.sellerservice.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sellerservice.entity.Items;
import com.sellerservice.entity.Seller;
import com.sellerservice.entity.Category;
import com.sellerservice.entity.SubCategory;

@Repository
public interface ItemsDao extends JpaRepository<Items, Integer> {

	@Query(value="FROM Items WHERE lower(itemName) LIKE %:itemName%")
	List<Items> getByitemName(@Param("itemName")String name);

     

}
