package com.cts.springbootjpa.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
public class BuyerDetails {
@Id
@GeneratedValue( strategy = GenerationType.IDENTITY)
private int buyerID;
private String password;
private String username;
private String emailId;
private String mobileNumber;
@Temporal(TemporalType.DATE)
@JsonFormat(pattern = "dd-mm-yyyy")
private Date createdDate;
public BuyerDetails() 
{ 
	
}

public BuyerDetails(int buyerID, String password, String username, String emailId, String mobileNumber,
		Date createdDate) {
	super();
	this.buyerID = buyerID;
	this.password = password;
	this.username = username;
	this.emailId = emailId;
	this.mobileNumber = mobileNumber;
	this.createdDate = createdDate;
}

public int getBuyerID() {
	return buyerID;
}
public void setBuyerID(int buyerID) {
	this.buyerID = buyerID;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getEmailId() {
	return emailId;
}
public void setEmailId(String emailId) {
	this.emailId = emailId;
}
public String getMobileNumber() {
	return mobileNumber;
}
public void setMobileNumber(String mobileNumber) {
	this.mobileNumber = mobileNumber;
}
public Date getCreatedDate() {
	return createdDate;
}
public void setCreatedDate(Date createdDate) {
	this.createdDate = createdDate;
}
public String getUsername() {
	return username;
}

public void setUsername(String username) {
	this.username = username;
}

@Override
public String toString() {
	return "BuyerDetails [buyerID=" + buyerID + ", password=" + password + ", username=" + username + ", emailId="
			+ emailId + ", mobileNumber=" + mobileNumber + ", createdDate=" + createdDate + "]";
}

}
